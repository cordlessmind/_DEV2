## 실습별 소스 수정 내역 확인 방법

1. 커밋 메시지 목록에서 확인하고 싶은 버전을 클릭하세요.

2. 원하는 파일의 수정 내역을 확인하세요.

3. [Browse files] 버튼을 클릭하면 해당 버전의 프로젝트 전체 내용을 확인하고 내려받을 수 있습니다.
 
 
 
 
## 장별 완성 소스 코드 확인

각 장의 실습을 모두 마쳤을 때 프로젝트 파일 전체의 소스 코드를 확인해 보세요.


03장 [완성 소스 확인](https://github.com/saintdragon2/do_it_django_atoz_frontend/tree/1cfd211a9caaf493b8971964773b6dcb8ce64df4)

04장 [완성 소스 확인](https://github.com/saintdragon2/do_it_django_atoz_frontend)

05장 (없음)

06장 [완성 소스 확인](https://github.com/saintdragon2/do_it_django_a_to_z/tree/8383f1aca91c24fc86cd71a4cb758e57b067463a)

07장 [완성 소스 확인](https://github.com/saintdragon2/do_it_django_a_to_z/tree/1724b036726ddbee477434d0d816d1ef6d988b03)
